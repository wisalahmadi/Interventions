import { TestBed } from '@angular/core/testing';

import { TypeproblemeService } from './typeprobleme.service';

describe('TypeproblemeService', () => {
  let service: TypeproblemeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TypeproblemeService);
  });

});
